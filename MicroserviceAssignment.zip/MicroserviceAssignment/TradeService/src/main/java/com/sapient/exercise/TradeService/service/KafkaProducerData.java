package com.sapient.exercise.TradeService.service;

public class KafkaProducerData {
	
 int tradeId;
 String status;
public KafkaProducerData() {
	super();
}
public int getTradeId() {
	return tradeId;
}
public void setTradeId(int tradeId) {
	this.tradeId = tradeId;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
 
 

}
