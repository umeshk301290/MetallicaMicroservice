package com.sapient.exercise.TradeService.service;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sapient.exercise.TradeService.model.MarketData;

@FeignClient("ZuulServer")
@RibbonClient("market-service")
public interface TradeDataClient {
	@GetMapping(value="/market-service/getPrice/{com}")
	public MarketData getMarketData(@PathVariable("com") String com);			
}
