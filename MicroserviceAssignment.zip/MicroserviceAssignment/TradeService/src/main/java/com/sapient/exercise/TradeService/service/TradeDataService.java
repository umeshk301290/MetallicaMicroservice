package com.sapient.exercise.TradeService.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.sapient.exercise.TradeService.model.MarketData;
import com.sapient.exercise.TradeService.model.TradeData;

@Service
public class TradeDataService {

	public static Map<Integer,TradeData> tradeMap;
	static Integer counter;
	static {
		tradeMap=new HashMap<Integer,TradeData>();
		counter=0;
	}

	public TradeData getAllTrading(@PathVariable("tradeId") int tradeId) {
		// TODO Auto-generated method stub
		 
		return tradeMap.get(tradeId);
	}

	public TradeItem insertData(TradeData data) {
		// TODO Auto-generated method stub
		++counter;
		tradeMap.put(counter, data);
		return new TradeItem(counter,data);
	}

	public TradeItem getMockTradingData(int tradeId) {
		// TODO Auto-generated method stub
		MarketData data=new MarketData("copper",12.6f);
		TradeData tradeData=new TradeData("buy","copper","delhi",data.getCommudityprice());
		TradeItem item=new TradeItem(tradeId, tradeData);
		return item;
	}


	
	
	
}
