package com.sapient.exercise.TradeService.Controllers;

import java.net.URI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.exercise.TradeService.Exception.TradeServiceException;
import com.sapient.exercise.TradeService.Messages.KafkaMessage;
import com.sapient.exercise.TradeService.model.MarketData;
import com.sapient.exercise.TradeService.model.TradeData;
import com.sapient.exercise.TradeService.service.KafkaProducerData;
import com.sapient.exercise.TradeService.service.TradeDataClient;
import com.sapient.exercise.TradeService.service.TradeDataService;
import com.sapient.exercise.TradeService.service.TradeItem;

@RestController
public class TradeServiceController {

	@Autowired
	private TradeDataService tradeService;
	@Autowired
	private TradeDataClient client;

	@Autowired
	Environment env;
	@Autowired
	ObjectMapper mapper;
	@Autowired
	KafkaMessage message;

	@GetMapping(value = "/tradeData/{tradeId}")
	public TradeData getTrade(@PathVariable("tradeId") int tradeId) throws TradeServiceException {
		TradeData tradeData = tradeService.getAllTrading(tradeId);
		if (tradeData == null) {
			throw new TradeServiceException(101, env.getProperty("no.match.found"));
		}
		return tradeData;
	}

	@PostMapping(value = "/tradeData")
	public ResponseEntity<Object> insertTrade(@RequestBody TradeData data)
			throws TradeServiceException, JsonProcessingException {
		validateTradeData(data);
		TradeItem tradeItem = tradeService.insertData(data);
		int count = tradeItem.getCounter();
		TradeData tradeData = tradeItem.getTradeData();
		MarketData market = client.getMarketData(tradeData.getCommodities());
		tradeData.setMarketPrice(market.getCommudityprice());
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{tradeId}").buildAndExpand(count)
				.toUri();

		String topic = env.getProperty("kafka.topic");
		KafkaProducerData kafkaData = new KafkaProducerData();
		kafkaData.setTradeId(count);
		kafkaData.setStatus(env.getProperty("message.status"));
		message.sendToKafka(topic, mapper.writeValueAsString(kafkaData));

		return ResponseEntity.created(location).build();

	}

	private void validateTradeData(TradeData data) throws TradeServiceException {
		if (data.getCommodities() == null || data.getCounterparties() == null || data.getLocation() == null)
			throw new TradeServiceException(102, env.getProperty("blank.fields"));

	}

}
