package com.sapient.exercise.TradeService.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class TradeServiceExceptionHandler extends ResponseEntityExceptionHandler {
	
@ExceptionHandler(TradeServiceException.class)
	public ResponseEntity<APIException> getException(TradeServiceException ex){
		
		APIException api=new APIException();
		api.setError(ex.getName());
		api.setExceptionId(ex.getCode());
		return new ResponseEntity<APIException>(api,HttpStatus.BAD_REQUEST);
		
		
		
	}
	
}	
	


