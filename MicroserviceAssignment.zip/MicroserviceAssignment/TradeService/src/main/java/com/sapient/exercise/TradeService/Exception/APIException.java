package com.sapient.exercise.TradeService.Exception;

public class APIException {

 int exceptionId;
 String error;
public APIException() {
	super();
	
}
public int getExceptionId() {
	return exceptionId;
}
public void setExceptionId(int exceptionId) {
	this.exceptionId = exceptionId;
}
public String getError() {
	return error;
}
public void setError(String error) {
	this.error = error;
}
 
}
