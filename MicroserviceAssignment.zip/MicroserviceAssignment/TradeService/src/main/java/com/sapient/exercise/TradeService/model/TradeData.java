package com.sapient.exercise.TradeService.model;

public class TradeData {

	private String counterparties;
	private String commodities;
	private String location;
	private float marketPrice;
	public TradeData(String counterparties, String commodities, String location, float marketPrice) {
		super();
		this.counterparties = counterparties;
		this.commodities = commodities;
		this.location = location;
		this.marketPrice = marketPrice;
	}
	
	public TradeData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getCounterparties() {
		return counterparties;
	}
	public void setCounterparties(String counterparties) {
		this.counterparties = counterparties;
	}
	public String getCommodities() {
		return commodities;
	}
	public void setCommodities(String commodities) {
		this.commodities = commodities;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public float getMarketPrice() {
		return marketPrice;
	}
	public void setMarketPrice(float marketPrice) {
		this.marketPrice = marketPrice;
	}
	
	
	

}
