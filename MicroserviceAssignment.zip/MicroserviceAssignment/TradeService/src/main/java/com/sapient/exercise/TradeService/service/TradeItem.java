package com.sapient.exercise.TradeService.service;

import com.sapient.exercise.TradeService.model.TradeData;

public class TradeItem {
	Integer counter;
	TradeData tradeData;
	public TradeItem(Integer counter, TradeData tradeData) {
		super();
		this.counter = counter;
		this.tradeData = tradeData;
	}
	public Integer getCounter() {
		return counter;
	}
	public void setCounter(Integer counter) {
		this.counter = counter;
	}
	public TradeData getTradeData() {
		return tradeData;
	}
	public void setTradeData(TradeData tradeData) {
		this.tradeData = tradeData;
	}
	
	

}
