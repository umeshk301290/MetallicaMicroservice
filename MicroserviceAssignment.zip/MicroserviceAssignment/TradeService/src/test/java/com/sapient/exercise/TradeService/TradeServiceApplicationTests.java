package com.sapient.exercise.TradeService;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sapient.exercise.TradeService.model.TradeData;
import com.sapient.exercise.TradeService.service.TradeDataService;
import com.sapient.exercise.TradeService.service.TradeItem;

@SpringBootTest
class TradeServiceApplicationTests {

	@Autowired
	private TradeDataService tradeService;

	@Test
	void contextLoads() {
	}

	@Test
	public void testTradeData() {
		TradeItem item = tradeService.getMockTradingData(1);
		assertEquals(1, item.getCounter());
		TradeData tradeData = new TradeData("buy", "copper", "delhi", 12.6f);
		assertEquals(tradeData.getMarketPrice(), item.getTradeData().getMarketPrice());

	}
	
	
	
	

}
