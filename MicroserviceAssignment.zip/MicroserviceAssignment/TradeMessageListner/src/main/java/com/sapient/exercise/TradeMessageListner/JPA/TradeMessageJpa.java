package com.sapient.exercise.TradeMessageListner.JPA;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sapient.exercise.TradeMessageListner.Model.KafkaProducerData;


@Repository
public interface TradeMessageJpa extends  JpaRepository<KafkaProducerData, Integer> {

}
