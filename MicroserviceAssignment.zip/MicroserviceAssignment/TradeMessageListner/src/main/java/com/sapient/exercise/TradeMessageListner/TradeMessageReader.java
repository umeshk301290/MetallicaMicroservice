package com.sapient.exercise.TradeMessageListner;

import java.io.IOException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.exercise.TradeMessageListner.JPA.TradeMessageJpa;
import com.sapient.exercise.TradeMessageListner.Model.KafkaProducerData;

@Component
public class TradeMessageReader {
@Autowired	
private ObjectMapper mapper;
@Autowired
Environment env;
@Autowired
private TradeMessageJpa tradeMessageJpa;
@KafkaListener(topics = "$'{kafka.topic}'")
public void recieve(ConsumerRecord<String, String> record) throws JsonParseException, JsonMappingException, IOException {
	
	String messageData=record.value();
	KafkaProducerData kafkaData=mapper.readValue(messageData, KafkaProducerData.class);
	tradeMessageJpa.save(kafkaData);
	kafkaData.setStatus(env.getProperty("kafka.topic"));	
	
}

}
