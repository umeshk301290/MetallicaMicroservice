package com.sapient.exercise.TradeMessageListner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradeMessageListnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradeMessageListnerApplication.class, args);
	}

}
