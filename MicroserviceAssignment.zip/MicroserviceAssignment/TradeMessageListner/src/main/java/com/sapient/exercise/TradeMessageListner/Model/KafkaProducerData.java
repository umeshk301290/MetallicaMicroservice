package com.sapient.exercise.TradeMessageListner.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class KafkaProducerData {
	
	@Id
 int tradeId;
 String status;
public KafkaProducerData() {
	super();
}
public int getTradeId() {
	return tradeId;
}
public void setTradeId(int tradeId) {
	this.tradeId = tradeId;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public KafkaProducerData(int tradeId, String status) {
	super();
	this.tradeId = tradeId;
	this.status = status;
}
 
 

}
