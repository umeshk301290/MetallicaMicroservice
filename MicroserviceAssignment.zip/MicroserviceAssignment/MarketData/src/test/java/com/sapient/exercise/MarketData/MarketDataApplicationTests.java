package com.sapient.exercise.MarketData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
