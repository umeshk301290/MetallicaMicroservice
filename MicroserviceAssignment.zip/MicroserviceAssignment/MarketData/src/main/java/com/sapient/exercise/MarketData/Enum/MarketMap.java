package com.sapient.exercise.MarketData.Enum;

public enum MarketMap {
	
    zinc("zinc",14.2f),
	gold("gold",104.2f),
	copper("copper",34.2f),
	aluminium("aluminium",44.2f);
	private String comName;
	private Float comPrice;
	private MarketMap(String comName, Float comPrice) {
		this.comName = comName;
		this.comPrice = comPrice;
	}
	public String getComName() {
		return comName;
	}
	public void setComName(String comName) {
		this.comName = comName;
	}
	public Float getComPrice() {
		return comPrice;
	}
	public void setComPrice(Float comPrice) {
		this.comPrice = comPrice;
	}
	
	

}
