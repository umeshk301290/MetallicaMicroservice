package com.sapient.exercise.MarketData.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sapient.exercise.MarketData.Model.MarketData;
import com.sapient.exercise.MarketData.Service.MarketDataService;

@RestController
public class MarketDataController {
	
@Autowired	
private MarketDataService marketService;	
@GetMapping(value="/getPrice/{com}")
	public MarketData getData(@PathVariable("com") String com) {
	MarketData marketData=marketService.getPriceForCommudity(com);
	
	
	    return marketData;
		
		
		
		
		
		
	}
	
	
	
	
	
}	


