package com.sapient.exercise.MarketData.Service;

import java.util.EnumMap;

import org.apache.commons.lang.enums.EnumUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.sapient.exercise.MarketData.Enum.MarketMap;
import com.sapient.exercise.MarketData.Model.MarketData;

@Service
public class MarketDataService {
	public MarketData getPriceForCommudity(@PathVariable("com") String com) {
		MarketData market=new MarketData();
		market.setCommudityName(MarketMap.valueOf(com).getComName());
		market.setCommudityprice(MarketMap.valueOf(com).getComPrice());
	    
		 return market;
	     
	
	}

}
