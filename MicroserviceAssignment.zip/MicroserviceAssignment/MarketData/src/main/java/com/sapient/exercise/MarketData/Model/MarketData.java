package com.sapient.exercise.MarketData.Model;

public class MarketData {
	String commudityName;
	Float commudityprice;
	public MarketData(String commudityName, float commudityprice) {
		super();
		this.commudityName = commudityName;
		this.commudityprice = commudityprice;
	}
	public MarketData() {
		
	}
	public String getCommudityName() {
		return commudityName;
	}
	public void setCommudityName(String commudityName) {
		this.commudityName = commudityName;
	}
	public Float getCommudityprice() {
		return commudityprice;
	}
	public void setCommudityprice(Float commudityprice) {
		this.commudityprice = commudityprice;
	}
	
	
 
}
